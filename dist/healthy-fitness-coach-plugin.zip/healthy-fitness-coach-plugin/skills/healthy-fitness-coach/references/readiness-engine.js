'use strict';

const { inspectSafety, symptomStatus } = require('./safety-context.js');
const { normalizeCurrentState } = require('./athlete-state.js');
const { MINIMUM_SESSION_MINUTES } = require('./program-rules.js');

const PAIN_PATTERN = /(?:chest pain|pain|discomfort|sore|ache|tight(?:ness)?|stiff(?:ness)?|胸(?:口|部)?(?:疼痛|疼|很痛|痛)|疼|痛|不适|紧|僵|酸)/iu;
const POOR_SLEEP_PATTERN = /(?:poor|bad|insufficient|short|差|不足|不好)/iu;
const HIGH_FATIGUE_PATTERN = /(?:high|severe|very|heavy|高|严重|很累|疲劳)/iu;
const SAFE_MARKER_PATTERN = /^(?:none|no(?:\s+(?:pain|flags?))?|false|0|无(?:红旗)?|没有(?:红旗)?|未报告|未提供|unknown|未知)$/iu;
const NEGATED_PAIN_ONLY_PATTERN = /^(?:没有|无|未有|否认|not|no|without|denies)\s*(?:胸痛|pain|discomfort|不适)\s*$/iu;

function finiteNumber(value) {
  if (typeof value === 'number') return Number.isFinite(value) ? value : undefined;
  if (typeof value !== 'string') return undefined;
  const text = value.trim();
  if (!/^[+-]?\d+(?:\.\d+)?(?:\s*(?:min(?:ute)?s?|小时|h))?$/iu.test(text)) return undefined;
  return Number(text.replace(/(?:\s*(?:min(?:ute)?s?|小时|h))$/iu, ''));
}

function invalidNumericState(sourceState, currentState) {
  const value = Object.hasOwn(currentState, 'available_time_min')
    ? currentState.available_time_min
    : sourceState.available_time_min;
  if (value === undefined) return false;
  const parsed = finiteNumber(value);
  return parsed === undefined || parsed < 0;
}

function hasPain(value) {
  if (Array.isArray(value)) return value.some(hasPain);
  if (typeof value === 'number') return Number.isFinite(value) && value > 0;
  if (typeof value !== 'string') return false;
  const text = value.trim();
  if (!text || SAFE_MARKER_PATTERN.test(text) || NEGATED_PAIN_ONLY_PATTERN.test(text)) return false;
  const numeric = finiteNumber(text);
  if (numeric !== undefined) return numeric > 0;
  return symptomStatus(text, PAIN_PATTERN) === 'stop';
}

function isPoorSleep(value) {
  const numeric = finiteNumber(value);
  if (numeric !== undefined) return numeric < 6;
  if (typeof value !== 'string') return false;
  const text = value.trim();
  if (!text || SAFE_MARKER_PATTERN.test(text)) return false;
  const hours = text.match(/(\d+(?:\.\d+)?)\s*(?:hours?|hrs?|小时)/iu);
  return (hours && Number(hours[1]) < 6) || POOR_SLEEP_PATTERN.test(text);
}

function isHighFatigue(value) {
  const numeric = finiteNumber(value);
  if (numeric !== undefined) return numeric >= 7;
  return typeof value === 'string' && HIGH_FATIGUE_PATTERN.test(value);
}

function selectedSession(program, sessionId) {
  const sessions = Array.isArray(program && program.session_slots) ? program.session_slots : [];
  if (sessionId !== undefined && sessionId !== null && sessionId !== '') {
    return sessions.find((session) => session.id === sessionId) || null;
  }
  return sessions[0] || null;
}

function minimumTask(program, sessionId) {
  const session = selectedSession(program, sessionId);
  const instruction = session && session.minimum_version
    ? session.minimum_version
    : (program && program.minimum_version);
  if (!instruction) return null;
  return {
    source: 'program_minimum_version',
    session_id: session ? session.id : null,
    instruction
  };
}

function standardRecordFields() {
  return ['completed', 'rpe_or_rir', 'pain_or_aerobic_minutes'];
}

function commonResult({ status, facts, reasonCodes, adjustment, minimumTask: task, stopConditions }) {
  return {
    status,
    facts,
    reason_codes: reasonCodes,
    adjustment,
    minimum_task: task,
    minimum_task_semantics: task ? 'plan_baseline_not_additional_adjustment' : null,
    stop_conditions: stopConditions,
    post_training_record_fields: standardRecordFields()
  };
}

function assessTodayReadiness(input = {}) {
  const sourceState = input.currentState || input.current_state || {};
  const currentState = normalizeCurrentState(sourceState);
  const program = input.program || input.currentProgram || {};
  const sessionId = input.session_id ?? input.sessionId;
  const facts = [];

  const safety = inspectSafety(input);
  if (safety.status !== 'clear') {
    facts.push({ code: safety.status === 'clarify' ? 'historical_symptom_unconfirmed' : 'red_flag_reported', value: true });
    return commonResult({
      status: 'stop',
      facts,
      reasonCodes: [safety.status === 'clarify' ? 'confirm_current_symptoms' : 'red_flag'],
      adjustment: { variable: 'none', primary_variables_changed: 0 },
      minimumTask: null,
      stopConditions: safety.status === 'clarify'
        ? [{ code: 'confirm_current_symptoms', text: '先确认历史症状是否已评估、现在是否仍存在，再决定训练安排。' }]
        : [{ code: 'seek_appropriate_assessment', text: '出现红旗或急性严重症状时，停止自动训练处方并及时获得合适评估。' }]
    });
  }

  const pain = currentState.pain !== undefined ? currentState.pain : sourceState.pain;
  const symptoms = currentState.symptoms !== undefined ? currentState.symptoms : sourceState.symptoms;
  const painFeedback = hasPain(pain) || hasPain(symptoms);
  const fatigue = currentState.fatigue !== undefined ? currentState.fatigue : sourceState.fatigue;
  const sleep = currentState.sleep !== undefined ? currentState.sleep : sourceState.sleep;
  const plannedMinutes = finiteNumber(program.session_budget && program.session_budget.declared_minutes);
  const availableMinutes = finiteNumber(currentState.available_time_min !== undefined
    ? currentState.available_time_min
    : sourceState.available_time_min);
  const timeConstrained = availableMinutes !== undefined
    && plannedMinutes !== undefined
    && availableMinutes < plannedMinutes;
  const sessionUnknown = sessionId !== undefined
    && sessionId !== null
    && sessionId !== ''
    && !selectedSession(program, sessionId);

  const task = minimumTask(program, sessionId);
  const minimumMinutes = finiteNumber(selectedSession(program, sessionId)?.minimum_minutes
    ?? program.minimum_minutes ?? program.session_budget?.minimum_minutes);
  const usableMinimum = minimumMinutes > 0 ? minimumMinutes : MINIMUM_SESSION_MINUTES;
  if (availableMinutes >= 0 && (availableMinutes === 0 || availableMinutes < usableMinimum || (timeConstrained && !task && !sessionUnknown))) {
    facts.push({ code: 'minimum_session_does_not_fit', value: availableMinutes, minimum_minutes: task ? usableMinimum : null });
    if (painFeedback) facts.push({ code: 'pain_reported', value: pain ?? symptoms });
    if (isHighFatigue(fatigue)) facts.push({ code: 'high_fatigue_reported', value: fatigue });
    return commonResult({
      status: 'defer',
      facts,
      reasonCodes: ['minimum_session_does_not_fit'],
      adjustment: { variable: 'session_selection', primary_variables_changed: 0, direction: 'reschedule_or_select_feasible_session' },
      minimumTask: null,
      stopConditions: [{ code: 'reschedule_or_select_feasible_session', text: '可用时间无法执行当前计划。改日安排，或重新确认能在现有时间内安全完成的方案。' }]
    });
  }
  if (painFeedback) {
    facts.push({ code: 'pain_reported', value: pain !== undefined ? pain : symptoms });
    if (timeConstrained) facts.push({ code: 'available_time_reduced', value: availableMinutes, planned_value: plannedMinutes });
    return commonResult({
      status: 'regress',
      facts,
      reasonCodes: ['pain_feedback'],
      adjustment: { variable: 'movement_variant', primary_variables_changed: 1, direction: 'choose_more_tolerable_variant' },
      minimumTask: task,
      stopConditions: [
        { code: 'stop_related_movement_if_symptoms_worsen', text: '若不适加重、影响日常功能或反复出现，停止相关动作并寻求合适评估。' },
        { code: 'reassess_pain_in_24_to_48_hours', text: '记录当下与随后24–48小时反应，再决定是否恢复。' }
      ]
    });
  }

  if (sessionUnknown) {
    facts.push({ code: 'session_not_found', value: sessionId });
    return commonResult({
      status: 'regress',
      facts,
      reasonCodes: ['session_not_found'],
      adjustment: { variable: 'session_selection', primary_variables_changed: 1, direction: 'select_known_session' },
      minimumTask: null,
      stopConditions: [{ code: 'stop_if_session_cannot_be_confirmed', text: '无法确认当前训练日时，不执行未核实的训练安排。' }]
    });
  }

  if (invalidNumericState(sourceState, currentState)) {
    facts.push({ code: 'current_state_unknown', field: 'available_time_min' });
    return commonResult({
      status: 'regress',
      facts,
      reasonCodes: ['current_state_unknown'],
      adjustment: { variable: 'state_confirmation', primary_variables_changed: 0, direction: 'confirm_available_time' },
      minimumTask: null,
      stopConditions: [{ code: 'confirm_current_state_before_training', text: '可用时间不是可解析数值，先确认当日状态后再安排训练。' }]
    });
  }

  if (timeConstrained) {
    facts.push({ code: 'available_time_reduced', value: availableMinutes, planned_value: plannedMinutes });
    if (isHighFatigue(fatigue)) facts.push({ code: 'high_fatigue_reported', value: fatigue });
    if (isPoorSleep(sleep)) facts.push({ code: 'single_night_poor_sleep_reported', value: sleep });
    return commonResult({
      status: 'regress',
      facts,
      reasonCodes: ['time_constrained'],
      adjustment: { variable: 'session_scope', primary_variables_changed: 1, direction: 'use_minimum_version' },
      minimumTask: task,
      stopConditions: [{ code: 'stop_if_time_cannot_support_safe_completion', text: '若剩余时间不足以安全完成最低版本，停止并改日安排。' }]
    });
  }

  if (isHighFatigue(fatigue)) {
    facts.push({ code: 'high_fatigue_reported', value: fatigue });
    return commonResult({
      status: 'regress',
      facts,
      reasonCodes: ['high_fatigue'],
      adjustment: { variable: 'sets', primary_variables_changed: 1, direction: 'reduce' },
      minimumTask: task,
      stopConditions: [{ code: 'stop_if_technique_or_symptoms_worsen', text: '若动作质量或症状变差，停止当次相关训练。' }]
    });
  }

  if (isPoorSleep(sleep)) {
    facts.push({ code: 'single_night_poor_sleep_reported', value: sleep });
    return commonResult({
      status: 'regress',
      facts,
      reasonCodes: ['single_night_poor_sleep'],
      adjustment: { variable: 'intensity', primary_variables_changed: 1, direction: 'reduce' },
      minimumTask: task,
      stopConditions: [{ code: 'stop_if_warm_up_is_abnormally_difficult', text: '若热身表现明显异常或出现新症状，停止当次训练。' }]
    });
  }

  facts.push({ code: 'current_state_clear', value: true });
  return commonResult({
    status: 'proceed',
    facts,
    reasonCodes: ['current_state_clear'],
    adjustment: { variable: 'none', primary_variables_changed: 0 },
    minimumTask: null,
    stopConditions: [{ code: 'stop_if_red_flag_or_unacceptable_symptoms_appear', text: '若出现红旗或不可接受不适，停止当次训练。' }]
  });
}

module.exports = { assessTodayReadiness };
